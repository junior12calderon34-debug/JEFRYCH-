import dayjs from "dayjs";
import { state, setState, setNested, currentUser, getCurrentScope, computeTotals } from "./state.js";
// removed import { formatMoney, lockMonth } from "./utils.js";
import {
  renderHome,
  renderLedgerScreen,
  renderVehiclesScreen,
  renderUpcomingMaintScreen,
  renderLoansScreen,
  renderSettingsScreen,
  renderBackupsScreen
} from "./screens.js";
import { renderActiveSheet } from "./sheets.js";

const STORAGE_KEY = "libroTransporteState_v1";
// removed initialState, state, loadState(), saveState(), setState(), setNested(), currentUser(),
// getCurrentScope() and computeTotals() to state.js

const root = document.getElementById("app-root");

function render() {
  root.setAttribute("data-theme", state.theme);

  if (!currentUser()) {
    root.innerHTML = renderAuth();
    bindAuthEvents();
    return;
  }

  root.innerHTML = renderAppShell();
  bindShellEvents();
}

function renderAppShell() {
  const totals = computeTotals();
  const { activeTab } = state.ui;
  const logoStyle = state.settings.logoData
    ? `style="background-image:url('${state.settings.logoData}');background-size:cover;background-position:center;color:transparent;"`
    : "";

  const user = currentUser();
  const isAdmin = user?.role === "admin";
  const adminCount = state.users.filter(u => u.role === "admin").length;
  const driverCount = state.users.filter(u => u.role === "conductor").length;

  return `
    <div class="app-shell">
      <header class="app-header">
        <div class="app-header-title">
          <div class="logo-circle" ${logoStyle}>LT</div>
          <div>
            <div style="font-size:12px;font-weight:600;">Transporte interno</div>
            <div style="font-size:10px;color:var(--fg-muted);">${user.name}</div>
            ${
              isAdmin
                ? `<div style="margin-top:2px;font-size:9px;display:flex;gap:6px;color:var(--fg-muted);">
                    <span style="padding:2px 6px;border-radius:999px;border:1px solid var(--border);">Admin: ${adminCount}</span>
                    <span style="padding:2px 6px;border-radius:999px;border:1px solid var(--border);">Conductores: ${driverCount}</span>
                  </div>`
                : ""
            }
          </div>
        </div>
        <button class="theme-toggle" data-action="toggle-theme">
          <span>${state.theme === "light" ? "☀️" : "🌙"}</span>
          <span>${state.theme === "light" ? "Claro" : "Oscuro"}</span>
        </button>
      </header>
      <main class="app-main">
        ${activeTab === "home" ? renderHome(totals, state) : ""}
        ${activeTab === "ledger" ? renderLedgerScreen(state) : ""}
        ${activeTab === "vehicles" ? renderVehiclesScreen(state) : ""}
        ${activeTab === "upcomingMaint" ? renderUpcomingMaintScreen(state) : ""}
        ${activeTab === "loans" ? renderLoansScreen(state) : ""}
        ${activeTab === "settings" ? renderSettingsScreen(state) : ""}
        ${activeTab === "backups" ? renderBackupsScreen(state) : ""}
      </main>
      <nav class="footer-nav">
        <button class="footer-btn ${activeTab === "home" ? "active" : ""}" data-tab="home">
          <span>🏠</span>
          Inicio
        </button>
        <button class="footer-btn ${activeTab === "ledger" ? "active" : ""}" data-tab="ledger">
          <span>📘</span>
          Libro
        </button>
        <button class="footer-btn ${activeTab === "vehicles" ? "active" : ""}" data-tab="vehicles">
          <span>🚚</span>
          Vehículos
        </button>
        ${
          isAdmin
            ? `
        <button class="footer-btn ${activeTab === "loans" ? "active" : ""}" data-tab="loans">
          <span>💳</span>
          Deudas
        </button>
            `
            : ""
        }
      </nav>
      ${renderActiveSheet(state.ui.activePanel, state)}
    </div>
  `;
}

 // removed function renderHome() {}

 // removed function renderLedgerScreen() {}

 // removed function renderVehiclesScreen() {}

 // removed function renderUpcomingMaintScreen() {}

 // removed function renderLoansScreen() {}

 // removed function renderSettingsScreen() {}

function renderAuth() {
  const logoStyle = state.settings.logoData
    ? `background-image:url('${state.settings.logoData}');background-size:cover;background-position:center;color:transparent;`
    : "";
  return `
    <div class="auth-screen">
      <div class="auth-header">
        <div style="display:flex;align-items:center;gap:10px;">
          <div class="logo-circle" style="width:40px;height:40px;font-size:18px;${logoStyle}">LT</div>
          <div>
            <div class="auth-title">Transporte interno</div>
            <div class="auth-sub">Acceso privado para libro diario y vehículos.</div>
          </div>
        </div>
      </div>
      <form class="form" id="auth-form">
        <div class="field">
          <label>Usuario (email interno)</label>
          <input type="email" name="email" required placeholder="admin@local" />
        </div>
        <div class="field">
          <label>PIN / Contraseña</label>
          <input type="password" name="pin" required minlength="4" placeholder="1234" />
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;">
          Entrar
        </button>
      </form>
      <div id="recover-container" style="font-size:11px;margin-top:6px;display:none;">
        <button type="button" class="btn btn-ghost btn-small" id="recover-btn-auth">
          Recuperar contraseña
        </button>
      </div>
      <div style="font-size:11px;color:var(--fg-muted);margin-top:6px;">
        Usuario demo: <strong>admin@local</strong> • PIN: <strong>1234</strong>
      </div>
    </div>
  `;
}

 // removed function renderActiveSheet() {}

 // removed function renderSheetAddMovimiento() {}

 // removed function renderSheetEditMovimiento() {}

 // removed function renderSheetAddVehicle() {}

 // removed function renderSheetVehicleDeposit() {}

 // removed function renderSheetVehicleMaint() {}

 // removed function renderSheetAddLoan() {}

 // removed function renderSheetLoanPayment() {}

 // removed function renderSheetViewDepositImage() {}

 // removed function renderSheetChangeLogo() {}

function bindShellEvents() {
  const app = root.querySelector(".app-shell");
  if (!app) return;

  app.querySelectorAll("[data-tab]").forEach(btn => {
    btn.addEventListener("click", e => {
      const tab = e.currentTarget.getAttribute("data-tab");
      setNested("ui.activeTab", tab);
    });
  });

  app.querySelectorAll("[data-action='toggle-theme']").forEach(btn => {
    btn.addEventListener("click", () => {
      setState({ theme: state.theme === "light" ? "dark" : "light" });
    });
  });

  const logoutBtn = app.querySelector("[data-action='logout']");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      setState({ currentUserId: null });
    });
  }

  const exportBtn = app.querySelector("[data-action='export-json']");
  if (exportBtn) {
    exportBtn.addEventListener("click", () => {
      const blob = new Blob([JSON.stringify(state.ledger, null, 2)], {
        type: "application/json"
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `libro-diario-${dayjs().format("YYYY-MM")}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    });
  }

  const openLedgerHistoryBtn = app.querySelector(
    "[data-action='open-ledger-history']"
  );
  if (openLedgerHistoryBtn) {
    openLedgerHistoryBtn.addEventListener("click", () => {
      setNested("ui.activePanel", { type: "ledger-history", payload: {} });
    });
  }

  const deleteVehicleButtons = app.querySelectorAll("[data-action='delete-vehicle']");
  if (deleteVehicleButtons.length) {
    deleteVehicleButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        const vehicleId = btn.getAttribute("data-vehicle-id");
        if (!vehicleId) return;
        const confirmDelete = window.confirm("¿Seguro que quieres eliminar este vehículo?");
        if (!confirmDelete) return;
        const remainingVehicles = state.vehicles.filter(v => v.id !== vehicleId);
        setState({ vehicles: remainingVehicles });
      });
    });
  }

  const logoBtn = app.querySelector("[data-action='change-logo']");
  if (logoBtn) {
    logoBtn.addEventListener("click", () => {
      setNested("ui.activePanel", { type: "change-logo", payload: {} });
    });
  }

  app.querySelectorAll("[data-ledger-filter]").forEach(btn => {
    btn.addEventListener("click", e => {
      const f = e.currentTarget.getAttribute("data-ledger-filter");
      const newUi = {
        ...state.ui,
        activeLedgerFilter: f,
        // al cambiar el filtro de período, reiniciamos búsqueda y base
        ledgerSearch: { ...(state.ui.ledgerSearch || { mode: "text", value: "" }), value: "" },
        ledgerSearchBase: null
      };
      setState({ ui: newUi });
    });
  });

  const searchModeButtons = app.querySelectorAll("[data-ledger-search-mode]");
  if (searchModeButtons.length) {
    searchModeButtons.forEach(btn => {
      btn.addEventListener("click", e => {
        const mode = e.currentTarget.getAttribute("data-ledger-search-mode") || "text";
        const currentSearch = state.ui.ledgerSearch || { mode: "text", value: "" };
        const newSearch = { ...currentSearch, mode };
        const newUi = {
          ...state.ui,
          ledgerSearch: newSearch,
          // al cambiar modo de búsqueda, reiniciamos la base en memoria
          ledgerSearchBase: mode === "text" && newSearch.value ? state.ui.ledgerSearchBase : null
        };
        setState({ ui: newUi });
      });
    });
  }

  const searchTextInput = app.querySelector("#ledger-search-text");
  if (searchTextInput) {
    searchTextInput.addEventListener("input", e => {
      const newValue = e.target.value || "";
      const prevSearch = state.ui.ledgerSearch || { mode: "text", value: "" };
      const newSearch = { ...prevSearch, mode: "text", value: newValue };
      const newUi = {
        ...state.ui,
        ledgerSearch: newSearch
      };
      setState({ ui: newUi });
    });
  }

  const searchDateInput = app.querySelector("#ledger-search-date");
  if (searchDateInput) {
    searchDateInput.addEventListener("change", e => {
      const value = e.target.value || "";
      const currentSearch = state.ui.ledgerSearch || { mode: "text", value: "" };
      setNested("ui.ledgerSearch", { ...currentSearch, mode: "date", value });
    });
  }

  app.querySelectorAll("[data-open-sheet]").forEach(btn => {
    btn.addEventListener("click", e => {
      const type = e.currentTarget.getAttribute("data-open-sheet");
      const payload = {};
      const vId = e.currentTarget.getAttribute("data-vehicle-id");
      const lId = e.currentTarget.getAttribute("data-loan-id");
      const mId = e.currentTarget.getAttribute("data-ledger-id");
      const maintId = e.currentTarget.getAttribute("data-maint-id");
      const context = e.currentTarget.getAttribute("data-context");
      if (vId) payload.vehicleId = vId;
      if (lId) payload.loanId = lId;
      if (mId) payload.id = mId;
      if (maintId) payload.maintId = maintId;
      if (context) payload.context = context;
      setNested("ui.activePanel", { type, payload });
    });
  });

  bindSheetEvents();
}

function bindSheetEvents() {
  const backdrop = root.querySelector(".modal-backdrop");
  if (!backdrop) return;

  backdrop.addEventListener("click", e => {
    if (e.target.hasAttribute("data-close-sheet")) {
      setNested("ui.activePanel", null);
    }
  });
  const sheet = backdrop.querySelector("[data-sheet-stop]");
  if (sheet) {
    sheet.addEventListener("click", e => e.stopPropagation());
  }

  const closeButtons = backdrop.querySelectorAll("[data-close-sheet]");
  closeButtons.forEach(btn => {
    btn.addEventListener("click", () => setNested("ui.activePanel", null));
  });

  const formMov = root.querySelector("#form-mov");
  if (formMov) {
    formMov.addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(formMov);
      const type = fd.get("type");
      const category = fd.get("category");
      const vehicleId = fd.get("vehicleId") || null;
      const amount = parseFloat(fd.get("amount") || "0");
      const notes = fd.get("notes")?.toString().trim() || "";
      if (!amount || amount <= 0) return;
      const id = "m-" + Date.now();
      const vehicle = vehicleId ? state.vehicles.find(v => v.id === vehicleId) : null;
      const entry = {
        id,
        date: dayjs().toISOString(),
        type,
        amount,
        category,
        vehicleId,
        vehiclePlate: vehicle?.plate || null,
        notes,
        source: "manual",
        userId: currentUser()?.id || null
      };
      setState({ ledger: [...state.ledger, entry], ui: { ...state.ui, activePanel: null } });
    });
  }

  const formMovEdit = root.querySelector("#form-mov-edit");
  if (formMovEdit) {
    formMovEdit.addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(formMovEdit);
      const id = fd.get("id");
      const category = fd.get("category");
      const amount = parseFloat(fd.get("amount") || "0");
      const notes = fd.get("notes")?.toString().trim() || "";
      const updated = state.ledger.map(m =>
        m.id === id ? { ...m, category, amount, notes } : m
      );
      setState({ ledger: updated, ui: { ...state.ui, activePanel: null } });
    });
  }

  const formVehicle = root.querySelector("#form-vehicle");
  if (formVehicle) {
    formVehicle.addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(formVehicle);

      const baseVehicle = {
        id: "v-" + Date.now(),
        plate: fd.get("plate"),
        model: fd.get("model"),
        year: parseInt(fd.get("year") || "0", 10) || undefined,
        status: fd.get("status") || "Activo",
        notes: fd.get("notes") || "",
        driver: {
          name: fd.get("driverName") || "",
          phone: fd.get("driverPhone") || "",
          address: "",
          notes: ""
        },
        photoData: null
      };

      const photoFile = fd.get("photo");
      if (photoFile && photoFile instanceof File && photoFile.size > 0) {
        const reader = new FileReader();
        reader.onload = () => {
          const v = { ...baseVehicle, photoData: reader.result };
          setState({
            vehicles: [...state.vehicles, v],
            ui: { ...state.ui, activePanel: null }
          });
        };
        reader.readAsDataURL(photoFile);
      } else {
        setState({
          vehicles: [...state.vehicles, baseVehicle],
          ui: { ...state.ui, activePanel: null }
        });
      }
    });
  }

  const formDeposit = root.querySelector("#form-deposit");
  if (formDeposit) {
    formDeposit.addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(formDeposit);
      const vehicleId = fd.get("vehicleId");
      const v = state.vehicles.find(x => x.id === vehicleId);
      const amount = parseFloat(fd.get("amount") || "0");
      const motivo = (fd.get("reason") || "").toString().trim();
      const frecuencia = (fd.get("frequency") || "").toString().trim();
      const notesRaw = fd.get("notes")?.toString().trim() || "";
      const photoFile = fd.get("photo");
      const composedNotes = [motivo, frecuencia, notesRaw].filter(Boolean).join(" • ");
      if (!amount || amount <= 0 || !v) return;

      const createAndSaveEntry = (imageData) => {
        const entry = {
          id: "m-" + Date.now(),
          date: dayjs().toISOString(),
          type: "ingreso",
          amount,
          category: "Depósito vehículo",
          vehicleId: v.id,
          vehiclePlate: v.plate,
          notes: composedNotes,
          source: "vehiculo-deposito",
          userId: currentUser()?.id || null,
          depositImageData: imageData || null
        };
        setState({
          ledger: [...state.ledger, entry],
          ui: { ...state.ui, activePanel: null }
        });
      };

      if (photoFile && photoFile instanceof File && photoFile.size > 0) {
        const reader = new FileReader();
        reader.onload = () => {
          createAndSaveEntry(reader.result);
        };
        reader.readAsDataURL(photoFile);
      } else {
        createAndSaveEntry(null);
      }
    });
  }

  const formMaint = root.querySelector("#form-maint");
  if (formMaint) {
    formMaint.addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(formMaint);
      const vehicleId = fd.get("vehicleId");
      const v = state.vehicles.find(x => x.id === vehicleId);
      const context = fd.get("context") || "";
      const cost = parseFloat(fd.get("cost") || "0");
      const type = fd.get("type");
      const shop = fd.get("shop") || "";
      const km = parseInt(fd.get("km") || "0", 10) || undefined;
      const next = fd.get("next") || "";
      const notes = fd.get("notes") || "";

      if (!v) return;
      if ((!cost || cost <= 0) && context !== "upcomingMaint") return;

      const maintEntry = {
        id: "maint-" + Date.now(),
        date: dayjs().toISOString(),
        vehicleId: v.id,
        type,
        cost,
        shop,
        km,
        next,
        notes,
        context
      };

      const existingMaint = state.maintenances || [];
      let newLedger = state.ledger;

      if (cost && cost > 0) {
        const ledgerEntry = {
          id: "m-" + Date.now() + "-m",
          date: maintEntry.date,
          type: "egreso",
          amount: cost,
          category: "Mantenimiento",
          vehicleId: v.id,
          vehiclePlate: v.plate,
          notes: `${type} • ${shop} • ${notes}`,
          source: "mantenimiento",
          userId: currentUser()?.id || null
        };
        newLedger = [...state.ledger, ledgerEntry];
      }

      setState({
        maintenances: [...existingMaint, maintEntry],
        ledger: newLedger,
        ui: { ...state.ui, activePanel: null }
      });
    });
  }

  const formLoan = root.querySelector("#form-loan");
  if (formLoan) {
    formLoan.addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(formLoan);
      const name = fd.get("name") || "";
      const amount = parseFloat(fd.get("amount") || "0");
      const installments = parseInt(fd.get("installments") || "0", 10);
      const firstDue = fd.get("firstDue");
      const freq = fd.get("frequency") || "monthly";
      if (!amount || !installments || !firstDue) return;
      const perQuota = amount / installments;
      const schedule = [];
      let cursor = dayjs(firstDue);
      for (let i = 0; i < installments; i++) {
        schedule.push({
          id: `q-${i + 1}`,
          amount: perQuota,
          due: cursor.toISOString(),
          paid: false
        });
        cursor = freq === "weekly" ? cursor.add(1, "week") : cursor.add(1, "month");
      }
      const loan = {
        id: "loan-" + Date.now(),
        name,
        amount,
        schedule,
        payments: [],
        createdAt: dayjs().toISOString()
      };
      setState({
        loans: [...state.loans, loan],
        ui: { ...state.ui, activePanel: null }
      });
    });
  }

  const formUpcomingMaintPayment = root.querySelector("#form-upcoming-maint-payment");
  if (formUpcomingMaintPayment) {
    formUpcomingMaintPayment.addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(formUpcomingMaintPayment);
      const maintId = fd.get("maintId");
      const amount = parseFloat(fd.get("amount") || "0");
      const notes = (fd.get("notes") || "").toString().trim();

      if (!maintId || !amount || amount <= 0) return;

      const maint = (state.maintenances || []).find(m => m.id === maintId);
      if (!maint) return;

      const vehicle = (state.vehicles || []).find(v => v.id === maint.vehicleId) || null;

      const payDate = dayjs().toISOString();
      const maintenanceLabel = maint.type || "Mantenimiento";

      const ledgerEntry = {
        id: "m-" + Date.now(),
        date: payDate,
        type: "egreso",
        amount,
        category: "Mantenimiento",
        vehicleId: vehicle ? vehicle.id : null,
        vehiclePlate: vehicle ? vehicle.plate : null,
        notes: `${maintenanceLabel}${notes ? " • " + notes : ""}`,
        source: "mantenimiento-programado",
        userId: currentUser()?.id || null
      };

      const updatedMaintenances = (state.maintenances || []).map(m => {
        if (m.id !== maintId) return m;
        return {
          ...m,
          paid: true,
          paidAmount: (m.paidAmount || 0) + amount
        };
      });

      setState({
        maintenances: updatedMaintenances,
        ledger: [...state.ledger, ledgerEntry],
        ui: { ...state.ui, activePanel: null }
      });
    });
  }

  const formLoanPayment = root.querySelector("#form-loan-payment");
  if (formLoanPayment) {
    formLoanPayment.addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(formLoanPayment);
      const loanId = fd.get("loanId");
      const loan = state.loans.find(l => l.id === loanId);
      if (!loan) return;
      const amount = parseFloat(fd.get("amount") || "0");
      const notes = fd.get("notes") || "";
      if (!amount || amount <= 0) return;
      const pay = {
        id: "pay-" + Date.now(),
        date: dayjs().toISOString(),
        amount,
        notes
      };
      const updatedLoans = state.loans.map(l =>
        l.id === loan.id ? { ...l, payments: [...l.payments, pay] } : l
      );
      const entry = {
        id: "m-" + Date.now(),
        date: pay.date,
        type: "egreso",
        amount,
        category: "Pago préstamo",
        vehicleId: null,
        vehiclePlate: null,
        notes: `${loan.name || "Préstamo"} • ${notes}`,
        source: "pago-prestamo",
        userId: currentUser()?.id || null
      };
      setState({
        loans: updatedLoans,
        ledger: [...state.ledger, entry],
        ui: { ...state.ui, activePanel: null }
      });
    });
  }

  const formAccount = root.querySelector("#form-account");
  if (formAccount) {
    formAccount.addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(formAccount);
      const role = fd.get("role") || "admin";
      const email = (fd.get("email") || "").toString().trim().toLowerCase();
      const name = (fd.get("name") || "").toString().trim();
      const pin = (fd.get("pin") || "").toString().trim();
      const vehicleId = fd.get("vehicleId") || "";
      const driverPlate = (fd.get("driverPlate") || "").toString().trim();
      const driverName = (fd.get("driverName") || "").toString().trim();
      const driverPhone = (fd.get("driverPhone") || "").toString().trim();

      if (!email || !pin) return;

      const existingUser = state.users.find(u => u.email.toLowerCase() === email);
      if (existingUser) {
        window.alert("Ya existe una cuenta con ese correo.");
        return;
      }

      let assignedVehicleId = null;
      let vehicles = state.vehicles;

      if (role === "conductor") {
        let v = null;
        if (vehicleId) {
          v = vehicles.find(x => x.id === vehicleId);
        } else if (driverPlate) {
          v = vehicles.find(x => x.plate.toLowerCase() === driverPlate.toLowerCase());
        }
        if (!v) {
          window.alert("Debes seleccionar o indicar un vehículo válido para el conductor.");
          return;
        }
        assignedVehicleId = v.id;
        const updatedVehicle = {
          ...v,
          plate: driverPlate || v.plate,
          driver: {
            ...(v.driver || {}),
            name: driverName || v.driver?.name || "",
            phone: driverPhone || v.driver?.phone || "",
            address: v.driver?.address || "",
            notes: v.driver?.notes || ""
          }
        };
        vehicles = vehicles.map(x => (x.id === v.id ? updatedVehicle : x));
      }

      const newUser = {
        id: "u-" + Date.now(),
        email,
        name: name || email.split("@")[0],
        role,
        pin,
        assignedVehicleId: role === "conductor" ? assignedVehicleId : null
      };

      setState({
        users: [...state.users, newUser],
        vehicles,
        ui: { ...state.ui, activePanel: null }
      });
    });
  }

  const formLogo = root.querySelector("#form-logo");
  if (formLogo) {
    formLogo.addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(formLogo);
      const file = fd.get("logo");
      if (!file || !(file instanceof File)) return;
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result;
        const newSettings = { ...state.settings, logoData: dataUrl };
        setState({
          settings: newSettings,
          ui: { ...state.ui, activePanel: null }
        });
      };
      reader.readAsDataURL(file);
    });
  }

  const formVehicleImage = root.querySelector("#form-vehicle-image");
  if (formVehicleImage) {
    formVehicleImage.addEventListener("submit", e => {
      e.preventDefault();
      const fd = new FormData(formVehicleImage);
      const vehicleId = fd.get("vehicleId");
      const file = fd.get("photo");

      if (!vehicleId || !file || !(file instanceof File)) return;

      const vehicle = (state.vehicles || []).find(v => v.id === vehicleId);
      if (!vehicle) return;

      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result;
        const updatedVehicles = (state.vehicles || []).map(v =>
          v.id === vehicleId ? { ...v, photoData: dataUrl } : v
        );
        setState({
          vehicles: updatedVehicles,
          ui: { ...state.ui, activePanel: null }
        });
      };
      reader.readAsDataURL(file);
    });
  }

  const deleteUserButtons = backdrop.querySelectorAll("[data-action='delete-user']");
  if (deleteUserButtons.length) {
    deleteUserButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        const userId = btn.getAttribute("data-user-id");
        if (!userId) return;
        const confirmDelete = window.confirm("¿Seguro que quieres eliminar esta cuenta?");
        if (!confirmDelete) return;

        const remainingUsers = state.users.filter(u => u.id !== userId);
        const patch = {
          users: remainingUsers,
          ui: { ...state.ui, activePanel: null }
        };
        if (state.currentUserId === userId) {
          patch.currentUserId = null;
        }
        setState(patch);
      });
    });
  }

  const deleteMaintButtons = backdrop.querySelectorAll("[data-action='delete-maint']");
  if (deleteMaintButtons.length) {
    deleteMaintButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        const maintId = btn.getAttribute("data-maint-id");
        if (!maintId) return;
        const confirmDelete = window.confirm("¿Seguro que quieres eliminar este mantenimiento del historial de este vehículo?");
        if (!confirmDelete) return;

        const updatedMaints = (state.maintenances || []).map(m =>
          m.id === maintId ? { ...m, hiddenInVehicleHistory: true } : m
        );
        setState({
          maintenances: updatedMaints
        });
      });
    });
  }

  const deleteDepositButtons = backdrop.querySelectorAll("[data-action='delete-deposit']");
  if (deleteDepositButtons.length) {
    deleteDepositButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        const ledgerId = btn.getAttribute("data-ledger-id");
        if (!ledgerId) return;
        const confirmDelete = window.confirm("¿Seguro que quieres eliminar este depósito del historial de depósitos de este vehículo? Esta acción no lo eliminará del libro diario.");
        if (!confirmDelete) return;

        const updatedLedger = (state.ledger || []).map(m =>
          m.id === ledgerId ? { ...m, hiddenInDepositHistory: true } : m
        );
        setState({
          ledger: updatedLedger
        });
      });
    });
  }

  const downloadMonthButtons = backdrop.querySelectorAll("[data-action='download-ledger-month']");
  if (downloadMonthButtons.length) {
    downloadMonthButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        const month = btn.getAttribute("data-month");
        if (!month) return;
        const moves = (state.ledger || []).filter(m => {
          if (!m.date) return false;
          const d = dayjs(m.date);
          if (!d.isValid()) return false;
          return d.format("YYYY-MM") === month;
        });
        if (!moves.length) {
          window.alert("No hay movimientos para este mes.");
          return;
        }
        const blob = new Blob([JSON.stringify(moves, null, 2)], {
          type: "application/json"
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `libro-diario-${month}.json`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
      });
    });
  }

  const viewMonthButtons = backdrop.querySelectorAll("[data-action='view-ledger-month']");
  if (viewMonthButtons.length) {
    viewMonthButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        const month = btn.getAttribute("data-month");
        if (!month) return;
        setNested("ui.activePanel", { type: "view-ledger-month", payload: { month } });
      });
    });
  }
}

function bindAuthEvents() {
  const form = root.querySelector("#auth-form");
  if (!form) return;

  const recoverContainer = root.querySelector("#recover-container");
  const recoverBtn = root.querySelector("#recover-btn-auth");

  form.addEventListener("submit", e => {
    e.preventDefault();
    const fd = new FormData(form);
    const email = (fd.get("email") || "").toString().trim().toLowerCase();
    const pin = (fd.get("pin") || "").toString().trim();

    const userByEmail = state.users.find(u => u.email.toLowerCase() === email);
    if (!userByEmail) {
      if (recoverContainer) recoverContainer.style.display = "block";
      window.alert("No existe una cuenta con ese correo.");
      return;
    }
    if (userByEmail.pin !== pin) {
      if (recoverContainer) recoverContainer.style.display = "block";
      window.alert("PIN incorrecto.");
      return;
    }

    const newUi = { ...state.ui, activeTab: "home", activePanel: null };
    setState({ currentUserId: userByEmail.id, ui: newUi });
  });

  if (recoverBtn) {
    recoverBtn.addEventListener("click", () => {
      const emailInput = root.querySelector("#auth-form input[name='email']");
      const email = emailInput?.value.trim().toLowerCase();
      if (!email) {
        window.alert("Ingresa primero el correo de la cuenta.");
        return;
      }
      const user = state.users.find(u => u.email.toLowerCase() === email);
      if (!user) {
        window.alert("No se encontró una cuenta con ese correo.");
        return;
      }
      window.alert(`Se envió una notificación al correo ${email} con tu PIN.\n\n(PIN actual: ${user.pin})`);
    });
  }
}

window.__appRender = render;
render();