import dayjs from "dayjs";
import { formatMoney, lockMonth } from "./utils.js";
import { getUserScope } from "./scope.js";
// removed function getUserScope() {} to scope.js

export function renderHome(totals, state) {
  const scope = getUserScope(state);
  const current = (state.users || []).find(u => u.id === state.currentUserId);
  const isAdmin = current?.role === "admin";
  const lastMoves = [...state.ledger]
    .filter(m => !scope.vehicleId || m.vehicleId === scope.vehicleId)
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 6);

  return `
    <section style="display:flex;flex-direction:column;gap:10px;height:100%;">
      <div class="cards-row">
        <div class="card">
          <div class="card-header">
            <div class="card-title">Ingresos mes</div>
            <div style="font-size:16px;">⬆️</div>
          </div>
          <div class="card-value" style="color:#16a34a;">$${formatMoney(totals.ingresos)}</div>
          <div class="card-sub">Actualizado al ${dayjs().format("DD/MM")}</div>
        </div>
        <div class="card">
          <div class="card-header">
            <div class="card-title">Egresos mes</div>
            <div style="font-size:16px;">⬇️</div>
          </div>
          <div class="card-value" style="color:#dc2626;">$${formatMoney(totals.egresos)}</div>
          <div class="card-sub">Control de gastos</div>
        </div>
      </div>
      <div class="card" style="display:flex;flex-direction:column;gap:6px;">
        <div class="card-header">
          <div class="card-title">Balance neto</div>
          <div class="badge">${dayjs().format("MMMM YYYY")}</div>
        </div>
        <div class="card-value" style="color:${totals.neto >= 0 ? "#16a34a" : "#dc2626"};">
          $${formatMoney(totals.neto)}
        </div>
        ${
          isAdmin
            ? `
        <div class="quick-actions">
          <button class="chip" data-open-sheet="add-ingreso">
            <span>＋</span>Ingreso
          </button>
          <button class="chip" data-open-sheet="add-egreso">
            <span>−</span>Gasto
          </button>
          <button class="chip" data-open-sheet="add-loan">
            <span>💳</span>Préstamo
          </button>
        </div>
            `
            : ""
        }
      </div>

      <div class="section-title-row">
        <div class="section-title">Últimos movimientos</div>
        <button class="section-action" data-tab="ledger" style="border:none;background:none;">Ver libro completo</button>
      </div>
      <div class="list" style="flex:0 0 150px;">
        <div class="list-scroll">
          ${
            lastMoves.length === 0
              ? `<div style="font-size:11px;color:var(--fg-muted);padding:10px;">Sin movimientos aún.</div>`
              : lastMoves
                  .map(m => {
                    const sign = m.type === "ingreso" ? "+" : "-";
                    const color = m.type === "ingreso" ? "#16a34a" : "#dc2626";
                    return `
                      <div class="list-item" style="border-color:rgba(148,163,184,0.25);background:var(--bg);">
                        <div class="list-item-main">
                          <div class="list-item-title">${m.category || "Movimiento"}</div>
                          <div class="list-item-sub">
                            ${dayjs(m.date).format("DD/MM HH:mm")} • ${m.vehiclePlate || "General"}
                            ${
                              m.depositImageData
                                ? ` • <button type="button" class="btn btn-ghost btn-small" style="padding:0 6px;font-size:11px;" data-open-sheet="view-deposit-image" data-ledger-id="${m.id}">📷</button>`
                                : ""
                            }
                          </div>
                        </div>
                        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:2px;">
                          <div class="list-item-amount" style="color:${color};">${sign}$${formatMoney(m.amount)}</div>
                          <div class="badge">${m.type === "ingreso" ? "Ingreso" : "Egreso"}</div>
                        </div>
                      </div>
                    `;
                  })
                  .join("")
          }
        </div>
      </div>

      <div class="section-title-row">
        <div class="section-title">Accesos rápidos</div>
        <button class="section-action" data-tab="settings" style="border:none;background:none;">⚙️ Ajustes</button>
      </div>
      <div class="primary-grid">
        <button class="primary-tile" data-tab="ledger">
          <div class="primary-tile-main">Libro Diario</div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-top:4px;">
            <div class="primary-tile-label">Movimientos diarios</div>
            <div class="primary-tile-icon">📘</div>
          </div>
        </button>
        <button class="primary-tile" data-tab="vehicles">
          <div class="primary-tile-main">Vehículos</div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-top:4px;">
            <div class="primary-tile-label">Depósitos y mantenimiento</div>
            <div class="primary-tile-icon">🚚</div>
          </div>
        </button>
        <button class="primary-tile" data-tab="upcomingMaint">
          <div class="primary-tile-main">Próximo mantenimiento</div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-top:4px;">
            <div class="primary-tile-label">Mantenimientos programados</div>
            <div class="primary-tile-icon">🛠️</div>
          </div>
        </button>
        ${
          isAdmin
            ? `
        <button class="primary-tile" data-tab="backups">
          <div class="primary-tile-main">Registros</div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-top:4px;">
            <div class="primary-tile-label">Exportar y ajustes</div>
            <div class="primary-tile-icon">🗂️</div>
          </div>
        </button>
        <button class="primary-tile" data-tab="loans">
          <div class="primary-tile-main">Panel financiero</div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-top:4px;">
            <div class="primary-tile-label">Préstamos y deudas</div>
            <div class="primary-tile-icon">📊</div>
          </div>
        </button>
            `
            : ""
        }
      </div>
    </section>
  `;
}

export function renderLedgerScreen(state) {
  const scope = getUserScope(state);
  const filter = state.ui.activeLedgerFilter;
  const searchText =
    (state.ui && state.ui.ledgerSearch && state.ui.ledgerSearch.value) || "";
  const normalizedSearch = searchText.trim().toLowerCase();

  const now = dayjs();
  const today = now.startOf("day");
  const startOfMonth = now.startOf("month");
  const endOfMonth = now.endOf("month");

  // Lógica simple de filtrado por fecha usando el campo date del registro
  const filteredMoves = (state.ledger || [])
    .filter(m => {
      if (!m.date) return false;
      if (scope.vehicleId && m.vehicleId !== scope.vehicleId) return false;

      const d = dayjs(m.date);
      if (!d.isValid()) return false;

      if (filter === "dia") {
        if (!d.isSame(today, "day")) return false;
      } else if (filter === "mes") {
        if (
          !(
            d.isAfter(startOfMonth.subtract(1, "millisecond")) &&
            d.isBefore(endOfMonth.add(1, "millisecond"))
          )
        ) {
          return false;
        }
      }

      if (!normalizedSearch) return true;

      const category = (m.category || "").toString().toLowerCase();
      const notes = (m.notes || "").toString().toLowerCase();
      const plate = (m.vehiclePlate || "general").toString().toLowerCase();

      return (
        category.includes(normalizedSearch) ||
        notes.includes(normalizedSearch) ||
        plate.includes(normalizedSearch)
      );
    })
    .sort((a, b) => {
      return dayjs(b.date).valueOf() - dayjs(a.date).valueOf();
    });

  return `
    <section class="screen">
      <div class="screen-header">
        <button class="btn btn-ghost btn-small" data-tab="home">← Inicio</button>
        <div><strong>Libro Diario</strong></div>
        <div class="pill-toggle">
          <button data-ledger-filter="dia" class="${filter === "dia" ? "active" : ""}">Hoy</button>
          <button data-ledger-filter="mes" class="${filter === "mes" ? "active" : ""}">Mes</button>
          <button data-ledger-filter="todo" class="${filter === "todo" ? "active" : ""}">Todo</button>
        </div>
      </div>
      <div style="padding:0 8px 4px;">
        <input
          id="ledger-search-text"
          type="text"
          placeholder="Buscar por palabra (categoría, notas, placa)"
          value="${searchText.replace(/"/g, "&quot;")}"
          style="width:100%;font-size:11px;padding:6px 8px;border-radius:999px;border:1px solid var(--border);background:var(--bg);color:var(--fg);"
        />
      </div>
      <div class="list" style="flex:1;">
        <div class="list-scroll">
          ${
            filteredMoves.length === 0
              ? `<div style="font-size:11px;color:var(--fg-muted);padding:10px;">Sin registros en este período.</div>`
              : filteredMoves
                  .map(m => {
                    const sign = m.type === "ingreso" ? "+" : "-";
                    const color = m.type === "ingreso" ? "#16a34a" : "#dc2626";
                    const locked = lockMonth(m.date);
                    return `
                      <div class="list-item" data-ledger-id="${m.id}">
                        <div class="list-item-main">
                          <div class="list-item-title">${m.category || "Movimiento"}</div>
                          <div class="list-item-sub">
                            ${dayjs(m.date).format("DD/MM/YYYY HH:mm")} • ${m.vehiclePlate || "General"}
                            ${locked ? " • Mes cerrado" : ""}
                            ${
                              m.depositImageData
                                ? ` • <button type="button" class="btn btn-ghost btn-small" style="padding:0 6px;font-size:11px;" data-open-sheet="view-deposit-image" data-ledger-id="${m.id}">📷</button>`
                                : ""
                            }
                          </div>
                          ${
                            m.notes
                              ? `<div class="list-item-sub" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${m.notes}</div>`
                              : ""
                          }
                        </div>
                        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:3px;">
                          <div class="list-item-amount" style="color:${color};">${sign}$${formatMoney(m.amount)}</div>
                          <div style="display:flex;gap:4px;align-items:center;">
                            <div class="badge">${m.type === "ingreso" ? "Ingreso" : "Egreso"}</div>
                            ${
                              locked
                                ? ""
                                : `<button class="btn btn-ghost btn-small" data-open-sheet="edit-ledger" data-ledger-id="${m.id}">✏️</button>`
                            }
                          </div>
                        </div>
                      </div>
                    `;
                  })
                  .join("")
          }
        </div>
      </div>
      <div style="display:flex;gap:8px;margin-top:8px;">
        <button class="btn btn-primary" style="flex:1;" data-open-sheet="add-ingreso">
          <span>＋</span>Ingreso
        </button>
        <button class="btn btn-primary" style="flex:1;background:linear-gradient(135deg,#fb7185,#ef4444);" data-open-sheet="add-egreso">
          <span>−</span>Gasto
        </button>
      </div>
    </section>
  `;
}

export function renderVehiclesScreen(state) {
  const scope = getUserScope(state);
  const current = (state.users || []).find(u => u.id === state.currentUserId);
  const isAdmin = current?.role === "admin";
  const vehicles = scope.vehicleId
    ? state.vehicles.filter(v => v.id === scope.vehicleId)
    : state.vehicles;
  return `
    <section class="screen">
      <div class="screen-header">
        <button class="btn btn-ghost btn-small" data-tab="home">← Inicio</button>
        <div><strong>Vehículos</strong></div>
        ${
          isAdmin
            ? `<button class="btn btn-ghost btn-small" data-open-sheet="add-vehicle">＋</button>`
            : `<div style="width:32px;"></div>`
        }
      </div>
      <div class="list" style="flex:1;">
        <div class="list-scroll">
          ${
            vehicles.length === 0
              ? `<div style="font-size:11px;color:var(--fg-muted);padding:10px;">Agrega tu primer vehículo.</div>`
              : vehicles
                  .map(v => {
                    return `
                      <div class="list-item" data-vehicle-id="${v.id}" style="border-color:rgba(6,182,212,0.4);background:var(--bg);">
                        <div class="list-item-main">
                          ${
                            v.photoData
                              ? `<div style="margin-bottom:4px;">
                                  <img src="${v.photoData}" alt="Foto ${v.plate}" style="width:100%;max-height:120px;object-fit:cover;border-radius:8px;border:1px solid var(--border);" />
                                </div>`
                              : ""
                          }
                          <div class="list-item-title">${v.plate} • ${v.model}</div>
                          <div class="list-item-sub">
                            ${v.year || ""} • ${v.status || "Sin estado"}
                          </div>
                          <div class="list-item-sub">
                            Chofer: ${v.driver?.name || "No asignado"}
                          </div>
                        </div>
                        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;">
                          <button class="btn btn-ghost btn-small" data-open-sheet="vehicle-deposit" data-vehicle-id="${v.id}">
                            Depósito
                          </button>
                          <button class="btn btn-ghost btn-small" data-open-sheet="vehicle-maint" data-vehicle-id="${v.id}">
                            Mantenimiento
                          </button>
                          <button class="btn btn-ghost btn-small" data-open-sheet="vehicle-maint-history" data-vehicle-id="${v.id}">
                            Historial mantenimientos
                          </button>
                          <button class="btn btn-ghost btn-small" data-open-sheet="vehicle-deposit-history" data-vehicle-id="${v.id}">
                            Historial depósitos
                          </button>
                          ${
                            isAdmin
                              ? `<button class="btn btn-ghost btn-small" data-action="delete-vehicle" data-vehicle-id="${v.id}">
                                  Eliminar
                                </button>`
                              : ""
                          }
                        </div>
                      </div>
                    `;
                  })
                  .join("")
          }
        </div>
      </div>
    </section>
  `;
}

export function renderUpcomingMaintScreen(state) {
  const scope = getUserScope(state);
  const upcomingMaint = (state.maintenances || [])
    .filter(m => m.next && m.next.toString().trim() !== "")
    .filter(m => !m.paid)
    .filter(m => !scope.vehicleId || m.vehicleId === scope.vehicleId)
    .sort((a, b) => (a.next || "").toString().localeCompare((b.next || "").toString()));

  const vehicles = (state.vehicles || []).filter(v => !scope.vehicleId || v.id === scope.vehicleId);

  return `
    <section class="screen">
      <div class="screen-header">
        <button class="btn btn-ghost btn-small" data-tab="home">← Inicio</button>
        <div><strong>Próximos mantenimientos</strong></div>
        <div style="width:56px;"></div>
      </div>
      <div class="list" style="flex:1;">
        <div class="list-scroll">
          ${
            upcomingMaint.length === 0
              ? `<div style="font-size:11px;color:var(--fg-muted);padding:10px;">Sin mantenimientos programados.</div>`
              : upcomingMaint
                  .map(m => {
                    const v = state.vehicles.find(vh => vh.id === m.vehicleId);
                    const plate = v ? `${v.plate} • ${v.model}` : "Vehículo";
                    const nextLabel = m.next ? m.next : "Sin dato";
                    const kmLabel = m.km ? `${m.km} km` : "";
                    const costLabel = m.cost ? `$${formatMoney(m.cost)}${kmLabel ? " • " + kmLabel : ""}` : kmLabel;
                    return `
                      <div class="list-item" style="border-color:rgba(6,182,212,0.4);background:var(--bg);">
                        <div class="list-item-main">
                          <div class="list-item-title">${plate}</div>
                          <div class="list-item-sub">
                            ${m.type || "Mantenimiento"} • Próximo: ${nextLabel}
                          </div>
                          ${
                            costLabel
                              ? `<div class="list-item-sub">${costLabel}${m.shop ? " • " + m.shop : ""}</div>`
                              : m.shop
                              ? `<div class="list-item-sub">${m.shop}</div>`
                              : ""
                          }
                        </div>
                        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;">
                          <div class="badge">Programado</div>
                          <button class="btn btn-ghost btn-small" data-open-sheet="upcoming-maint-payment" data-maint-id="${m.id}">
                            Abrir
                          </button>
                          <div class="list-item-sub" style="font-size:10px;">
                            Registrado: ${dayjs(m.date).format("DD/MM/YY")}
                          </div>
                        </div>
                      </div>
                    `;
                  })
                  .join("")
          }

          ${
            vehicles.length === 0
              ? ""
              : `
                <div style="font-size:11px;color:var(--fg-muted);padding:8px 6px 4px;">
                  Todos los vehículos
                </div>
                ${vehicles
                  .map(v => {
                    return `
                      <div class="list-item" style="border-color:rgba(148,163,184,0.25);background:var(--bg);">
                        <div class="list-item-main">
                          <div class="list-item-title">${v.plate} • ${v.model}</div>
                          <div class="list-item-sub">
                            ${v.year || ""} • ${v.status || "Sin estado"}
                          </div>
                        </div>
                        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;">
                          <button class="btn btn-ghost btn-small" data-open-sheet="vehicle-maint" data-vehicle-id="${v.id}" data-context="upcomingMaint">
                            P. Mantenimientos
                          </button>
                        </div>
                      </div>
                    `;
                  })
                  .join("")}
              `
          }
        </div>
      </div>
    </section>
  `;
}

export function renderLoansScreen(state) {
  const loans = state.loans;
  return `
    <section class="screen">
      <div class="screen-header">
        <button class="btn btn-ghost btn-small" data-tab="home">← Inicio</button>
        <div><strong>Préstamos / Deudas</strong></div>
        <button class="btn btn-ghost btn-small" data-open-sheet="add-loan">＋</button>
      </div>
      <div class="list" style="flex:1;">
        <div class="list-scroll">
          ${
            loans.length === 0
              ? `<div style="font-size:11px;color:var(--fg-muted);padding:10px;">Sin préstamos registrados.</div>`
              : loans
                  .map(l => {
                    const pagado = l.payments.reduce((s, p) => s + p.amount, 0);
                    const pendiente = l.amount - pagado;
                    const nextPayment = l.schedule.find(s => !s.paid);
                    return `
                      <div class="list-item" data-loan-id="${l.id}">
                        <div class="list-item-main">
                          <div class="list-item-title">${l.name || "Préstamo"}</div>
                          <div class="list-item-sub">
                            Total: $${formatMoney(l.amount)} • Pagado: $${formatMoney(pagado)} • Pendiente: $${formatMoney(pendiente)}
                          </div>
                          <div class="list-item-sub">
                            ${
                              nextPayment
                                ? `Próxima cuota: $${formatMoney(nextPayment.amount)} • ${dayjs(nextPayment.due).format("DD/MM/YYYY")}`
                                : "Completado"
                            }
                          </div>
                        </div>
                        <div style="display:flex;flex-direction:column;gap:4px;align-items:flex-end;">
                          <div class="badge">${l.schedule.length} cuotas</div>
                          <button class="btn btn-ghost btn-small" data-open-sheet="loan-payment" data-loan-id="${l.id}">
                            Registrar pago
                          </button>
                        </div>
                      </div>
                    `;
                  })
                  .join("")
          }
        </div>
      </div>
    </section>
  `;
}

export function renderSettingsScreen(state) {
  const user = (state.users || []).find(u => u.id === state.currentUserId);
  const isAdmin = user?.role === "admin";

  return `
    <section class="screen">
      <div class="screen-header">
        <button class="btn btn-ghost btn-small" data-tab="home">← Inicio</button>
        <div><strong>Ajustes</strong></div>
        <button class="btn btn-ghost btn-small" data-action="logout">Salir</button>
      </div>
      <div class="list" style="flex:1;">
        <div class="list-scroll">
          ${
            isAdmin
              ? `
          <div class="list-item">
            <div class="list-item-main">
              <div class="list-item-title">Cuentas</div>
              <div class="list-item-sub">Ver y administrar cuentas existentes</div>
            </div>
            <button class="btn btn-ghost btn-small" data-open-sheet="accounts">
              Abrir
            </button>
          </div>
          <div class="list-item">
            <div class="list-item-main">
              <div class="list-item-title">Cambiar logotipo</div>
              <div class="list-item-sub">Seleccionar imagen de la galería del teléfono</div>
            </div>
            <button class="btn btn-ghost btn-small" data-open-sheet="change-logo">
              Cambiar
            </button>
          </div>
          <div class="list-item">
            <div class="list-item-main">
              <div class="list-item-title">Cambiar imagen vehículo</div>
              <div class="list-item-sub">Actualizar la fotografía de un vehículo desde la galería</div>
            </div>
            <button class="btn btn-ghost btn-small" data-open-sheet="change-vehicle-image">
              Cambiar
            </button>
          </div>
          <div class="list-item">
            <div class="list-item-main">
              <div class="list-item-title">Realizar backup</div>
              <div class="list-item-sub">Generar copia de seguridad del libro</div>
            </div>
            <button class="btn btn-ghost btn-small" data-action="export-json">
              Realizar backup
            </button>
          </div>
          <div class="list-item">
            <div class="list-item-main">
              <div class="list-item-title">Restaurar backup</div>
              <div class="list-item-sub">Restaurar datos desde una copia previa</div>
            </div>
            <button class="btn btn-ghost btn-small">
              Restaurar
            </button>
          </div>
              `
              : ""
          }
        </div>
      </div>
    </section>
  `;
}

export function renderBackupsScreen(state) {
  const user = (state.users || []).find(u => u.id === state.currentUserId);
  const isAdmin = user?.role === "admin";

  return `
    <section class="screen">
      <div class="screen-header">
        <button class="btn btn-ghost btn-small" data-tab="home">← Inicio</button>
        <div><strong>Cierres</strong></div>
        <button class="btn btn-ghost btn-small" data-action="logout">Salir</button>
      </div>
      <div class="list" style="flex:1;">
        <div class="list-scroll">
          ${
            isAdmin
              ? `
          <div class="list-item">
            <div class="list-item-main">
              <div class="list-item-title">Historial libro diario</div>
              <div class="list-item-sub">Guardar libros diarios por mes automáticamente</div>
            </div>
            <button class="btn btn-ghost btn-small" data-action="open-ledger-history">
              Abrir
            </button>
          </div>
              `
              : ""
          }
        </div>
      </div>
    </section>
  `;
}