import dayjs from "dayjs";

export const STORAGE_KEY = "libroTransporteState_v1";

const initialState = {
  theme: "light",
  currentUserId: null,
  users: [
    {
      id: "u-admin",
      email: "admin@local",
      name: "Administrador",
      role: "admin",
      pin: "1234"
    },
    {
      id: "u-admin-2",
      email: "junior12calderon34@gmail.com",
      name: "Administrador Junior",
      role: "admin",
      pin: "Junior123"
    }
  ],
  vehicles: [
    {
      id: "v-001",
      plate: "AAA-001",
      model: "Camión 3T",
      year: 2018,
      status: "Activo",
      notes: "",
      driver: {
        name: "Juan Pérez",
        phone: "+593 999999",
        address: "",
        notes: ""
      }
    }
  ],
  loans: [],
  ledger: [],
  maintenances: [],
  // settings can hold arbitrary UI preferences like a custom logo
  settings: {
    logoData: null
  },
  ui: {
    activeTab: "home",
    activeLedgerFilter: "mes",
    activePanel: null,
    ledgerSearch: {
      mode: "text",
      value: ""
    },
    ledgerSearchBase: null
  }
};

export let state = loadState();

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return initialState;
    const parsed = JSON.parse(raw);
    return { ...initialState, ...parsed };
  } catch {
    return initialState;
  }
}

export function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function setState(patch) {
  state = { ...state, ...patch };
  saveState();
  if (typeof window !== "undefined" && typeof window.__appRender === "function") {
    window.__appRender();
  }
}

export function setNested(path, value) {
  const segments = path.split(".");
  const clone = structuredClone(state);
  let ptr = clone;
  for (let i = 0; i < segments.length - 1; i++) {
    ptr = ptr[segments[i]];
  }
  ptr[segments.at(-1)] = value;
  state = clone;
  saveState();
  if (typeof window !== "undefined" && typeof window.__appRender === "function") {
    window.__appRender();
  }
}

export function currentUser() {
  return state.users.find(u => u.id === state.currentUserId) || null;
}

export function getCurrentScope() {
  const user = currentUser();
  if (user && user.role === "conductor" && user.assignedVehicleId) {
    return { vehicleId: user.assignedVehicleId };
  }
  return { vehicleId: null };
}

export function computeTotals() {
  const now = dayjs();
  const currentMonth = now.format("YYYY-MM");
  let ingresos = 0;
  let egresos = 0;
  const scope = getCurrentScope();
  for (const m of state.ledger) {
    const mMonth = m.date.slice(0, 7);
    if (mMonth !== currentMonth) continue;
    if (scope.vehicleId && m.vehicleId !== scope.vehicleId) continue;
    if (m.type === "ingreso") ingresos += m.amount;
    if (m.type === "egreso") egresos += m.amount;
  }
  return {
    ingresos,
    egresos,
    neto: ingresos - egresos
  };
}