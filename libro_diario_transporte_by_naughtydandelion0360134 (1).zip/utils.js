import dayjs from "dayjs";

export function formatMoney(v) {
  return v.toLocaleString("es-EC", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

export function lockMonth(dateStr) {
  const entryMonth = dayjs(dateStr).startOf("month");
  const nowMonth = dayjs().startOf("month");
  return entryMonth.isBefore(nowMonth);
}