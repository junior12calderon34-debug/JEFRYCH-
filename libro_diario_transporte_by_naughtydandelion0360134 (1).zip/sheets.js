import dayjs from "dayjs";
import { formatMoney, lockMonth } from "./utils.js";

export function renderActiveSheet(panel, state) {
  if (!panel) return "";
  const payload = panel.payload || {};
  switch (panel.type) {
    case "add-ingreso":
      return renderSheetAddMovimiento("ingreso", state);
    case "add-egreso":
      return renderSheetAddMovimiento("egreso", state);
    case "edit-ledger":
      return renderSheetEditMovimiento(panel.payload.id, state);
    case "add-vehicle":
      return renderSheetAddVehicle(state);
    case "vehicle-deposit":
      return renderSheetVehicleDeposit(payload.vehicleId, state);
    case "vehicle-maint":
      return renderSheetVehicleMaint(payload.vehicleId, state, { context: payload.context });
    case "vehicle-maint-history":
      return renderSheetVehicleMaintHistory(payload.vehicleId, state);
    case "vehicle-deposit-history":
      return renderSheetVehicleDepositHistory(payload.vehicleId, state);
    case "add-loan":
      return renderSheetAddLoan(state);
    case "loan-payment":
      return renderSheetLoanPayment(payload.loanId, state);
    case "change-logo":
      return renderSheetChangeLogo(state);
    case "change-vehicle-image":
      return renderSheetChangeVehicleImage(state);
    case "view-deposit-image":
      return renderSheetViewDepositImage(payload.id, state);
    case "create-account":
      return renderSheetCreateAccount(state);
    case "accounts":
      return renderSheetAccounts(state);
    case "upcoming-maint-payment":
      return renderSheetUpcomingMaintPayment(panel.payload.maintId, state);
    case "ledger-history":
      return renderSheetLedgerHistory(state);
    case "view-ledger-month":
      return renderSheetViewLedgerMonth(panel.payload.month, state);
    default:
      return "";
  }
}

function renderSheetAddMovimiento(type, state) {
  const title = type === "ingreso" ? "Nuevo ingreso" : "Nuevo gasto";
  const color = type === "ingreso" ? "#16a34a" : "#dc2626";
  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <div style="display:flex;flex-direction:column;gap:2px;">
            <strong>${title}</strong>
            <span style="font-size:11px;color:var(--fg-muted);">${dayjs().format("DD/MM/YYYY HH:mm")}</span>
          </div>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cancelar</button>
        </div>
        <form class="form" id="form-mov">
          <input type="hidden" name="type" value="${type}" />
          <div class="field">
            <label>Categoría</label>
            <select name="category" required>
              ${
                type === "ingreso"
                  ? `
                    <option value="Depósito">Depósito</option>
                    <option value="Ingreso general">Ingreso general</option>
                  `
                  : `
                    <option value="Gasto operativo">Gasto operativo</option>
                    <option value="Mantenimiento">Mantenimiento</option>
                    <option value="Pago préstamo">Pago préstamo</option>
                  `
              }
            </select>
          </div>
          <div class="field">
            <label>Vehículo (opcional)</label>
            <select name="vehicleId">
              <option value="">— General —</option>
              ${state.vehicles.map(v => `<option value="${v.id}">${v.plate} • ${v.model}</option>`).join("")}
            </select>
          </div>
          <div class="field">
            <label>Monto</label>
            <input type="number" step="0.01" min="0" name="amount" required placeholder="0.00" />
          </div>
          <div class="field">
            <label>Observaciones</label>
            <textarea name="notes" placeholder="Detalle breve"></textarea>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;background:${color};">
            Guardar
          </button>
        </form>
      </div>
    </div>
  `;
}

function renderSheetEditMovimiento(id, state) {
  const m = state.ledger.find(x => x.id === id);
  if (!m) return "";
  const locked = lockMonth(m.date);
  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Editar movimiento</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <form class="form" id="form-mov-edit">
          <input type="hidden" name="id" value="${m.id}" />
          <div class="field">
            <label>Fecha y hora</label>
            <input type="text" value="${dayjs(m.date).format("DD/MM/YYYY HH:mm")}" disabled />
          </div>
          <div class="field">
            <label>Categoría</label>
            <input name="category" value="${m.category || ""}" ${locked ? "disabled" : ""} />
          </div>
          <div class="field">
            <label>Monto</label>
            <input type="number" step="0.01" min="0" name="amount" value="${m.amount}" ${locked ? "disabled" : ""} />
          </div>
          <div class="field">
            <label>Observaciones</label>
            <textarea name="notes" ${locked ? "disabled" : ""}>${m.notes || ""}</textarea>
          </div>
          ${
            locked
              ? `<div style="font-size:11px;color:var(--fg-muted);">El mes ya está cerrado. Solo lectura.</div>`
              : `<button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;">Guardar cambios</button>`
          }
        </form>
      </div>
    </div>
  `;
}

function renderSheetAddVehicle(_state) {
  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Nuevo vehículo</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <form class="form" id="form-vehicle">
          <div class="field">
            <label>Placa</label>
            <input name="plate" required />
          </div>
          <div class="field">
            <label>Modelo</label>
            <input name="model" required />
          </div>
          <div class="field">
            <label>Año</label>
            <input type="number" name="year" />
          </div>
          <div class="field">
            <label>Estado</label>
            <input name="status" placeholder="Activo, en taller, etc." />
          </div>
          <div class="field">
            <label>Chofer</label>
            <input name="driverName" placeholder="Nombre del conductor" />
          </div>
          <div class="field">
            <label>Teléfono chofer</label>
            <input name="driverPhone" />
          </div>
          <div class="field">
            <label>Observaciones</label>
            <textarea name="notes"></textarea>
          </div>
          <div class="field">
            <label>Fotografía del vehículo</label>
            <input type="file" name="photo" accept="image/*" />
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;">Guardar</button>
        </form>
      </div>
    </div>
  `;
}

function renderSheetVehicleDeposit(vehicleId, state) {
  const v = state.vehicles.find(x => x.id === vehicleId);
  if (!v) return "";
  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Depósito • ${v.plate}</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <form class="form" id="form-deposit">
          <input type="hidden" name="vehicleId" value="${v.id}" />
          <div class="field">
            <label>Motivo de depósito</label>
            <select name="reason" required>
              <option value="Cajas">Cajas</option>
              <option value="Valores pendientes">Valores pendientes</option>
              <option value="Otro">Otro</option>
            </select>
          </div>
          <div class="field">
            <label>Tipo de depósito</label>
            <select name="frequency" required>
              <option value="Diario">Diario</option>
              <option value="Semanal">Semanal</option>
              <option value="Mensual">Mensual</option>
            </select>
          </div>
          <div class="field">
            <label>Monto</label>
            <input type="number" step="0.01" min="0" name="amount" required />
          </div>
          <div class="field">
            <label>Observaciones</label>
            <textarea name="notes" placeholder="Detalle del depósito"></textarea>
          </div>
          <div class="field">
            <label>Fotografía comprobante (opcional)</label>
            <input type="file" name="photo" accept="image/*" capture="environment" />
          </div>
          <div style="font-size:11px;color:var(--fg-muted);">
            Este depósito se registrará también como <strong>ingreso</strong> en el libro diario, incluyendo motivo, tipo de depósito y si tiene comprobante fotográfico.
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;">Guardar</button>
        </form>
      </div>
    </div>
  `;
}

function renderSheetVehicleDepositHistory(vehicleId, state) {
  const v = state.vehicles.find(x => x.id === vehicleId);
  if (!v) return "";
  const current = (state.users || []).find(u => u.id === state.currentUserId);
  const isAdmin = current?.role === "admin";

  const deposits = (state.ledger || [])
    .filter(m => m.type === "ingreso")
    .filter(m => m.source === "vehiculo-deposito")
    .filter(m => m.vehicleId === vehicleId)
    .filter(m => !m.hiddenInDepositHistory);

  const historyHtml =
    deposits.length === 0
      ? `
          <div style="font-size:11px;color:var(--fg-muted);margin-top:6px;">
            Sin depósitos registrados para este vehículo.
          </div>
        `
      : `
          <div style="font-size:11px;color:var(--fg-muted);margin-bottom:4px;">
            Historial de depósitos • ${v.plate} • ${v.model}
          </div>
          <div style="max-height:60vh;overflow-y:auto;padding-right:2px;">
            ${deposits
              .slice()
              .sort((a, b) => (b.date || "").localeCompare(a.date || ""))
              .map(m => {
                const dateLabel = m.date ? dayjs(m.date).format("DD/MM/YY HH:mm") : "";
                const amountLabel = typeof m.amount === "number" ? `$${formatMoney(m.amount)}` : "";
                const notes = m.notes || "";
                const photoBadge = m.depositImageData
                  ? `<span style="margin-left:4px;">📷</span>`
                  : "";
                const meta = [dateLabel, amountLabel].filter(Boolean).join(" • ");
                const deleteButton = isAdmin
                  ? `<button class="btn btn-ghost btn-small" data-action="delete-deposit" data-ledger-id="${m.id}" style="margin-top:4px;">
                       Eliminar
                     </button>`
                  : "";
                return `
                  <div style="font-size:11px;padding:6px 2px;border-bottom:1px solid var(--border);">
                    <div><strong>${m.category || "Depósito"}</strong>${photoBadge}</div>
                    ${meta ? `<div style="color:var(--fg-muted);">${meta}</div>` : ""}
                    ${notes ? `<div style="color:var(--fg-muted);">${notes}</div>` : ""}
                    ${deleteButton}
                  </div>
                `;
              })
              .join("")}
          </div>
        `;

  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Historial depósitos • ${v.plate}</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <div class="form" style="padding-right:2px;">
          ${historyHtml}
        </div>
      </div>
    </div>
  `;
}

function renderSheetVehicleMaintHistory(vehicleId, state) {
  const v = state.vehicles.find(x => x.id === vehicleId);
  if (!v) return "";
  const allVehicleMaints = (state.maintenances || []).filter(
    m => m.vehicleId === v.id && !m.hiddenInVehicleHistory
  );
  const current = (state.users || []).find(u => u.id === state.currentUserId);
  const isAdmin = current?.role === "admin";

  const historyHtml =
    allVehicleMaints.length === 0
      ? `
          <div style="font-size:11px;color:var(--fg-muted);margin-top:6px;">
            Sin historial de mantenimientos para este vehículo.
          </div>
        `
      : `
          <div style="font-size:11px;color:var(--fg-muted);margin-bottom:4px;">
            Historial de mantenimientos • ${v.plate} • ${v.model}
          </div>
          <div style="max-height:60vh;overflow-y:auto;padding-right:2px;">
            ${allVehicleMaints
              .slice()
              .sort((a, b) => (b.date || "").localeCompare(a.date || ""))
              .map(m => {
                const dateLabel = m.date ? dayjs(m.date).format("DD/MM/YY") : "";
                const kmLabel = m.km ? `${m.km} km` : "";
                const costBase = typeof m.cost === "number" && m.cost > 0 ? m.cost : 0;
                const paidExtra = typeof m.paidAmount === "number" && m.paidAmount > 0 ? m.paidAmount : 0;
                const totalCost = costBase + paidExtra;
                const costLabel = totalCost ? `$${formatMoney(totalCost)}` : "";
                const shopLabel = m.shop || "";
                const meta = [dateLabel, kmLabel, costLabel, shopLabel].filter(Boolean).join(" • ");
                const paidLabel = m.paid ? "Pagado" : "";
                const colorStyle = m.paid ? "color:#2563eb;" : "";
                const deleteButton = isAdmin
                  ? `<button class="btn btn-ghost btn-small" data-action="delete-maint" data-maint-id="${m.id}" style="margin-top:4px;">
                       Eliminar
                     </button>`
                  : "";
                return `
                  <div style="font-size:11px;padding:6px 2px;border-bottom:1px solid var(--border);${colorStyle}">
                    <div><strong>${m.type || "Mantenimiento"}</strong>${paidLabel ? ` • ${paidLabel}` : ""}</div>
                    ${meta ? `<div style="color:var(--fg-muted);">${meta}</div>` : ""}
                    ${m.notes ? `<div style="color:var(--fg-muted);">${m.notes}</div>` : ""}
                    ${deleteButton}
                  </div>
                `;
              })
              .join("")}
          </div>
        `;

  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Historial mantenimiento • ${v.plate}</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <div class="form" style="padding-right:2px;">
          ${historyHtml}
        </div>
      </div>
    </div>
  `;
}

function renderSheetVehicleMaint(vehicleId, state, options = {}) {
  const v = state.vehicles.find(x => x.id === vehicleId);
  if (!v) return "";
  const fromUpcoming = options.context === "upcomingMaint";

  const contextHiddenInput = fromUpcoming
    ? `<input type="hidden" name="context" value="upcomingMaint" />`
    : "";

  const costAndShopFields = fromUpcoming
    ? ""
    : `
          <div class="field">
            <label>Costo</label>
            <input type="number" step="0.01" min="0" name="cost" required />
          </div>
          <div class="field">
            <label>Taller</label>
            <input name="shop" />
          </div>
    `;

  const allVehicleMaints = (state.maintenances || []).filter(m => m.vehicleId === v.id);

  const maintSection =
    fromUpcoming
      ? ""
      : allVehicleMaints.length === 0
      ? `
          <div style="font-size:11px;color:var(--fg-muted);margin-top:6px;">
            Sin historial de mantenimientos para este vehículo.
          </div>
        `
      : `
          <div style="font-size:11px;color:var(--fg-muted);margin-top:6px;margin-bottom:2px;">
            Historial de mantenimientos
          </div>
          <div style="max-height:120px;overflow-y:auto;padding-right:2px;">
            ${allVehicleMaints
              .slice()
              .sort((a, b) => (b.date || "").localeCompare(a.date || ""))
              .map(m => {
                const dateLabel = m.date ? dayjs(m.date).format("DD/MM/YY") : "";
                const kmLabel = m.km ? `${m.km} km` : "";
                const costBase = typeof m.cost === "number" && m.cost > 0 ? m.cost : 0;
                const paidExtra = typeof m.paidAmount === "number" && m.paidAmount > 0 ? m.paidAmount : 0;
                const totalCost = costBase + paidExtra;
                const costLabel = totalCost ? `$${formatMoney(totalCost)}` : "";
                const shopLabel = m.shop || "";
                const meta = [dateLabel, kmLabel, costLabel, shopLabel].filter(Boolean).join(" • ");
                const colorStyle = m.paid ? "color:#2563eb;" : "";
                return `
                  <div style="font-size:11px;padding:4px 2px;border-bottom:1px solid var(--border);${colorStyle}">
                    <div><strong>${m.type || "Mantenimiento"}</strong></div>
                    ${meta ? `<div style="color:var(--fg-muted);">${meta}</div>` : ""}
                    ${m.notes ? `<div style="color:var(--fg-muted);">${m.notes}</div>` : ""}
                  </div>
                `;
              })
              .join("")}
          </div>
        `;

  let historyHtml = maintSection;

  if (fromUpcoming) {
    const futureUpcomingMaints = allVehicleMaints.filter(m => {
      if (m.context !== "upcomingMaint") return false;
      if (!m.next) return false;
      const d = dayjs(m.next);
      if (!d.isValid()) return false;
      return d.isAfter(dayjs(), "day") || d.isSame(dayjs(), "day");
    });

    const movesSection =
      futureUpcomingMaints.length === 0
        ? `
          <div style="font-size:11px;color:var(--fg-muted);margin-top:8px;">
            Sin próximos mantenimientos generados desde esta ventana.
          </div>
        `
        : `
          <div style="font-size:11px;color:var(--fg-muted);margin-top:8px;margin-bottom:2px;">
            Historial de movimientos (P. Mantenimientos futuros)
          </div>
          <div style="max-height:120px;overflow-y:auto;padding-right:2px;">
            ${futureUpcomingMaints
              .slice()
              .sort((a, b) => (a.next || "").toString().localeCompare((b.next || "").toString()))
              .map(m => {
                const nextLabel = m.next || "";
                const dateLabel = m.date ? dayjs(m.date).format("DD/MM/YY") : "";
                const kmLabel = m.km ? `${m.km} km` : "";
                const notes = m.notes ? ` • ${m.notes}` : "";
                const meta = [dateLabel, kmLabel].filter(Boolean).join(" • ");
                return `
                  <div style="font-size:11px;padding:4px 2px;border-bottom:1px solid var(--border);">
                    <div><strong>${m.type || "Mantenimiento"}</strong> • Próximo: ${nextLabel}</div>
                    ${meta || notes
                      ? `<div style="color:var(--fg-muted);">
                          ${meta}${notes}
                        </div>`
                      : ""}
                  </div>
                `;
              })
              .join("")}
          </div>
        `;

    historyHtml = movesSection;
  }

  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Mantenimiento • ${v.plate}</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <form class="form" id="form-maint">
          <input type="hidden" name="vehicleId" value="${v.id}" />
          ${contextHiddenInput}
          <div class="field">
            <label>Tipo</label>
            <select name="type" required>
              <option value="Cambio de pieza">Cambio de pieza</option>
              <option value="Cambio de aceite">Cambio de aceite</option>
              <option value="Mecánica">Mecánica</option>
              <option value="Otros">Otros</option>
            </select>
          </div>
          ${costAndShopFields}
          <div class="field">
            <label>Kilometraje</label>
            <input type="number" name="km" />
          </div>
          <div class="field">
            <label>Próxima revisión (km o fecha)</label>
            <input name="next" />
          </div>
          <div class="field">
            <label>Notas</label>
            <textarea name="notes"></textarea>
          </div>
          <div style="font-size:11px;color:var(--fg-muted);">
            El costo se registrará como <strong>egreso</strong> en el libro diario.
          </div>
          ${historyHtml}
          <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;background:#ef4444;">
            Guardar
          </button>
        </form>
      </div>
    </div>
  `;
}

function renderSheetAddLoan(_state) {
  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Nuevo préstamo / deuda</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <form class="form" id="form-loan">
          <div class="field">
            <label>Nombre / referencia</label>
            <input name="name" placeholder="Banco, proveedor, etc." />
          </div>
          <div class="field">
            <label>Monto total</label>
            <input type="number" step="0.01" min="0" name="amount" required />
          </div>
          <div class="field">
            <label>Número de cuotas</label>
            <input type="number" min="1" name="installments" required />
          </div>
          <div class="field">
            <label>Primera fecha de vencimiento</label>
            <input type="date" name="firstDue" required />
          </div>
          <div class="field">
            <label>Frecuencia</label>
            <select name="frequency">
              <option value="monthly">Mensual</option>
              <option value="weekly">Semanal</option>
            </select>
          </div>
          <div style="font-size:11px;color:var(--fg-muted);">
            Cada pago registrado se reflejará como egreso en el libro diario.
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;">Guardar</button>
        </form>
      </div>
    </div>
  `;
}

function renderSheetLoanPayment(loanId, state) {
  const loan = state.loans.find(l => l.id === loanId);
  if (!loan) return "";
  const pagado = loan.payments.reduce((s, p) => s + p.amount, 0);
  const pendiente = loan.amount - pagado;
  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Pago préstamo</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <div style="font-size:12px;margin-bottom:4px;">
          <div><strong>${loan.name || "Préstamo"}</strong></div>
          <div>Total: $${formatMoney(loan.amount)} • Pendiente: $${formatMoney(pendiente)}</div>
        </div>
        <form class="form" id="form-loan-payment">
          <input type="hidden" name="loanId" value="${loan.id}" />
          <div class="field">
            <label>Monto del pago</label>
            <input type="number" step="0.01" min="0" max="${pendiente}" name="amount" required />
          </div>
          <div class="field">
            <label>Observaciones</label>
            <textarea name="notes" placeholder="Pago parcial, cuota N, etc."></textarea>
          </div>
          <div style="font-size:11px;color:var(--fg-muted);">
            Se registrará como egreso en el libro diario (categoría: Pago préstamo).
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;background:#ef4444;">
            Registrar pago
          </button>
        </form>
      </div>
    </div>
  `;
}

function renderSheetViewDepositImage(id, state) {
  const m = state.ledger.find(x => x.id === id);
  const hasImage = m && m.depositImageData;
  if (!m || !hasImage) return "";
  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Comprobante de depósito</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <div style="font-size:11px;color:var(--fg-muted);margin-bottom:6px;">
          ${m.category || "Depósito"} • ${m.vehiclePlate || "General"} • ${dayjs(m.date).format("DD/MM/YYYY HH:mm")}
        </div>
        <div style="border-radius:12px;overflow:hidden;border:1px solid var(--border);max-height:60vh;display:flex;justify-content:center;align-items:center;background:var(--bg);">
          <img src="${m.depositImageData}" alt="Comprobante de depósito" style="max-width:100%;max-height:60vh;display:block;object-fit:contain;" />
        </div>
      </div>
    </div>
  `;
}

function renderSheetChangeLogo(_state) {
  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Cambiar logo interno</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <form class="form" id="form-logo">
          <div class="field">
            <label>Selecciona una imagen de tu galería</label>
            <input type="file" name="logo" accept="image/*" required />
          </div>
          <div style="font-size:11px;color:var(--fg-muted);">
            El logo se usará en la pantalla de inicio de sesión y en la cabecera de la app.
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;">
            Guardar logo
          </button>
        </form>
      </div>
    </div>
  `;
}

function renderSheetChangeVehicleImage(state) {
  const vehicles = state.vehicles || [];
  if (!vehicles.length) {
    return `
      <div class="modal-backdrop" data-close-sheet>
        <div class="sheet" data-sheet-stop>
          <div class="sheet-handle"></div>
          <div class="sheet-title-row">
            <strong>Cambiar imagen vehículo</strong>
            <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
          </div>
          <div class="form" style="padding-right:2px;">
            <div style="font-size:11px;color:var(--fg-muted);">
              No hay vehículos registrados para actualizar su fotografía.
            </div>
          </div>
        </div>
      </div>
    `;
  }

  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Cambiar imagen vehículo</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <form class="form" id="form-vehicle-image">
          <div class="field">
            <label>Selecciona vehículo</label>
            <select name="vehicleId" required>
              <option value="">— Elige un vehículo —</option>
              ${vehicles
                .map(v => `<option value="${v.id}">${v.plate} • ${v.model}</option>`)
                .join("")}
            </select>
          </div>
          <div class="field">
            <label>Nueva fotografía</label>
            <input type="file" name="photo" accept="image/*" required />
          </div>
          <div style="font-size:11px;color:var(--fg-muted);">
            La imagen se cargará desde la galería del teléfono y reemplazará la fotografía actual del vehículo elegido.
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;">
            Guardar imagen
          </button>
        </form>
      </div>
    </div>
  `;
}

function renderSheetCreateAccount(state) {
  const vehicles = state.vehicles || [];
  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Nueva cuenta</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <form class="form" id="form-account">
          <div class="field">
            <label>Tipo de cuenta</label>
            <select name="role" required>
              <option value="admin">Administrador</option>
              <option value="conductor">Conductor</option>
            </select>
          </div>
          <div class="field">
            <label>Correo</label>
            <input type="email" name="email" required placeholder="correo@ejemplo.com" />
          </div>
          <div class="field">
            <label>Nombre</label>
            <input name="name" required placeholder="Nombre de la persona" />
          </div>
          <div class="field">
            <label>PIN / Clave</label>
            <input type="password" name="pin" required minlength="4" />
          </div>
          <div class="field">
            <label>Vehículo (solo conductor)</label>
            <select name="vehicleId">
              <option value="">— Selecciona vehículo —</option>
              ${vehicles.map(v => `<option value="${v.id}">${v.plate} • ${v.model}</option>`).join("")}
            </select>
          </div>
          <div class="field">
            <label>Placa (solo conductor)</label>
            <input name="driverPlate" placeholder="AAA-001" />
          </div>
          <div class="field">
            <label>Nombre del conductor</label>
            <input name="driverName" placeholder="Nombre completo" />
          </div>
          <div class="field">
            <label>Teléfono del conductor</label>
            <input name="driverPhone" placeholder="+593 ..." />
          </div>
          <div style="font-size:11px;color:var(--fg-muted);">
            Las cuentas de conductor se vinculan a un solo vehículo y todos sus movimientos se verán también en la cuenta administrador.
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;">
            Guardar cuenta
          </button>
        </form>
      </div>
    </div>
  `;
}

function renderSheetUpcomingMaintPayment(maintId, state) {
  const maint = (state.maintenances || []).find(m => m.id === maintId);
  if (!maint) return "";
  const vehicle = (state.vehicles || []).find(v => v.id === maint.vehicleId);
  const plate = vehicle ? `${vehicle.plate} • ${vehicle.model}` : "Vehículo";
  const nextLabel = maint.next || "";
  const kmLabel = maint.km ? `${maint.km} km` : "";
  const shopLabel = maint.shop || "";
  const meta = [nextLabel, kmLabel, shopLabel].filter(Boolean).join(" • ");

  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Mantenimiento programado</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <div style="font-size:12px;margin-bottom:6px;">
          <div><strong>${plate}</strong></div>
          <div style="color:var(--fg-muted);">
            ${maint.type || "Mantenimiento"}${meta ? " • " + meta : ""}
          </div>
        </div>
        <form class="form" id="form-upcoming-maint-payment">
          <input type="hidden" name="maintId" value="${maint.id}" />
          <div class="field">
            <label>Monto de pago</label>
            <input type="number" step="0.01" min="0" name="amount" required />
          </div>
          <div class="field">
            <label>Notas</label>
            <textarea name="notes" placeholder="Detalle del pago (opcional)"></textarea>
          </div>
          <div style="font-size:11px;color:var(--fg-muted);">
            Este pago se registrará como <strong>egreso</strong> en el libro diario y el mantenimiento se marcará como realizado.
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;margin-top:4px;background:#ef4444;">
            Registrar pago
          </button>
        </form>
      </div>
    </div>
  `;
}

function renderSheetAccounts(state) {
  const users = state.users || [];
  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Cuentas registradas</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <div class="form" style="padding-right:2px;">
          ${
            users.length === 0
              ? `<div style="font-size:11px;color:var(--fg-muted);">No hay cuentas registradas.</div>`
              : users
                  .map(u => {
                    const roleLabel = u.role === "admin" ? "Administrador" : "Conductor";
                    return `
                      <div style="border-radius:12px;border:1px solid var(--border);padding:8px 10px;margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;font-size:12px;">
                        <div style="display:flex;flex-direction:column;gap:2px;">
                          <div><strong>${u.name || u.email}</strong></div>
                          <div style="color:var(--fg-muted);">${u.email} • ${roleLabel}</div>
                        </div>
                        <button class="btn btn-ghost btn-small" data-action="delete-user" data-user-id="${u.id}">
                          Eliminar
                        </button>
                      </div>
                    `;
                  })
                  .join("")
          }
        </div>
      </div>
    </div>
  `;
}

function renderSheetViewLedgerMonth(month, state) {
  if (!month) return "";

  const ledger = state.ledger || [];
  const moves = ledger
    .filter(m => {
      if (!m.date) return false;
      const d = dayjs(m.date);
      if (!d.isValid()) return false;
      return d.format("YYYY-MM") === month;
    })
    .sort((a, b) => dayjs(a.date).valueOf() - dayjs(b.date).valueOf());

  const label = dayjs(month + "-01").format("MMMM YYYY");

  let totalNet = 0;
  moves.forEach(m => {
    const amt = typeof m.amount === "number" ? m.amount : 0;
    if (m.type === "ingreso") totalNet += amt;
    else if (m.type === "egreso") totalNet -= amt;
  });
  const totalColor = totalNet >= 0 ? "#16a34a" : "#dc2626";
  const totalLabel = `$${formatMoney(Math.abs(totalNet))}`;
  const totalSign = totalNet >= 0 ? "+" : "-";

  const listContent =
    moves.length === 0
      ? `<div style="font-size:11px;color:var(--fg-muted);">No hay movimientos para este mes.</div>`
      : `
        <div style="max-height:60vh;overflow-y:auto;padding-right:2px;">
          ${moves
            .map(m => {
              const dateLabel = m.date ? dayjs(m.date).format("DD/MM/YYYY HH:mm") : "";
              const typeLabel = m.type === "ingreso" ? "Ingreso" : "Egreso";
              const sign = m.type === "ingreso" ? "+" : "-";
              const color = m.type === "ingreso" ? "#16a34a" : "#dc2626";
              const amountLabel =
                typeof m.amount === "number"
                  ? `${sign}$${formatMoney(m.amount)}`
                  : "";
              const plate = m.vehiclePlate || "General";
              const category = m.category || "Movimiento";
              const notes = m.notes || "";
              const meta = [dateLabel, plate, typeLabel].filter(Boolean).join(" • ");

              return `
                <div style="padding:6px 4px;border-bottom:1px solid var(--border);font-size:11px;">
                  <div style="display:flex;justify-content:space-between;align-items:center;">
                    <div style="display:flex;flex-direction:column;gap:2px;">
                      <strong>${category}</strong>
                      ${meta ? `<span style="color:var(--fg-muted);">${meta}</span>` : ""}
                      ${
                        notes
                          ? `<span style="color:var(--fg-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${notes}</span>`
                          : ""
                      }
                    </div>
                    <div style="margin-left:8px;font-weight:600;color:${color};">
                      ${amountLabel}
                    </div>
                  </div>
                </div>
              `;
            })
            .join("")}
        </div>
      `;

  const totalBlock = `
    <div style="font-size:12px;margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;">
      <span style="color:var(--fg-muted);">Suma total del mes</span>
      <span style="font-weight:700;color:${totalColor};">${totalSign}${totalLabel}</span>
    </div>
  `;

  const content = `
    ${totalBlock}
    ${listContent}
  `;

  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Libro diario • ${label}</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <div class="form" style="padding-right:2px;">
          ${content}
        </div>
      </div>
    </div>
  `;
}

function renderSheetLedgerHistory(state) {
  const ledger = state.ledger || [];

  const byMonth = new Map();
  ledger.forEach(m => {
    if (!m.date) return;
    const d = dayjs(m.date);
    if (!d.isValid()) return;
    const key = d.format("YYYY-MM");
    if (!byMonth.has(key)) byMonth.set(key, []);
    byMonth.get(key).push(m);
  });

  const months = Array.from(byMonth.entries()).sort((a, b) =>
    b[0].localeCompare(a[0])
  );

  const content =
    months.length === 0
      ? `<div style="font-size:11px;color:var(--fg-muted);">No hay movimientos para generar libros mensuales.</div>`
      : `
        <div style="font-size:11px;color:var(--fg-muted);margin-bottom:4px;">
          Selecciona un mes para descargar el libro diario correspondiente.
        </div>
        <div style="max-height:60vh;overflow-y:auto;padding-right:2px;">
          ${months
            .map(([month, moves]) => {
              const label = dayjs(month + "-01").format("MMMM YYYY");
              let net = 0;
              moves.forEach(m => {
                const amt = typeof m.amount === "number" ? m.amount : 0;
                if (m.type === "ingreso") net += amt;
                else if (m.type === "egreso") net -= amt;
              });
              const color = net >= 0 ? "#16a34a" : "#dc2626";
              const sign = net >= 0 ? "+" : "-";
              const totalLabel = `${sign}$${formatMoney(Math.abs(net))}`;
              return `
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 4px;border-bottom:1px solid var(--border);font-size:12px;">
                  <div style="display:flex;flex-direction:column;gap:2px;">
                    <div style="display:flex;align-items:center;gap:6px;">
                      <strong>${label}</strong>
                      <span style="font-weight:600;color:${color};">${totalLabel}</span>
                    </div>
                    <span style="font-size:11px;color:var(--fg-muted);">${moves.length} movimientos</span>
                  </div>
                  <div style="display:flex;gap:6px;">
                    <button class="btn btn-ghost btn-small" data-action="view-ledger-month" data-month="${month}">
                      Ver
                    </button>
                    <button class="btn btn-ghost btn-small" data-action="download-ledger-month" data-month="${month}">
                      Descargar
                    </button>
                  </div>
                </div>
              `;
            })
            .join("")}
        </div>
      `;

  return `
    <div class="modal-backdrop" data-close-sheet>
      <div class="sheet" data-sheet-stop>
        <div class="sheet-handle"></div>
        <div class="sheet-title-row">
          <strong>Historial libro diario</strong>
          <button class="btn btn-ghost btn-small" data-close-sheet>Cerrar</button>
        </div>
        <div class="form" style="padding-right:2px;">
          ${content}
        </div>
      </div>
    </div>
  `;
}