export function getUserScope(state) {
  const user = (state.users || []).find(u => u.id === state.currentUserId);
  if (user && user.role === "conductor" && user.assignedVehicleId) {
    return { vehicleId: user.assignedVehicleId };
  }
  return { vehicleId: null };
}